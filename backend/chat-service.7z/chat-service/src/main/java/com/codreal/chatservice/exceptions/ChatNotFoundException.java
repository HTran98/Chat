package com.codreal.chatservice.exceptions;

public class ChatNotFoundException extends Throwable {
}
