package com.codreal.chatservice.services;

import com.codreal.chatservice.dto.MessageDto;
import com.codreal.chatservice.model.Message;
import com.codreal.chatservice.repository.MessageRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MessageServiceImpl implements MessageService {
    @Autowired
    private MessageRepository messageRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Override
    public MessageDto addMessge(MessageDto messageDto) {
        Message mess = modelMapper.map(messageDto,Message.class);
        long timestamp = System.currentTimeMillis();
        mess.setTimestamp(timestamp);
        mess = messageRepository.save(mess);
        return modelMapper.map(mess,MessageDto.class);
    }

    @Override
    public List<MessageDto> getListMessage(String roomId) {
        List<Message> messageList = messageRepository.findMessageByRoomIdOrderByTimestamp(roomId);
        List<MessageDto> messageDtoList = messageList.stream().map(message -> modelMapper.map(message,MessageDto.class)).collect(
                Collectors.toList());
        return messageDtoList;
    }

}
